package com.medner.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.medner.app.R
import com.medner.app.data.MedicalEntity

class MainActivity : AppCompatActivity() {

    private lateinit var inputText: TextInputEditText
    private lateinit var analyzeButton: MaterialButton
    private lateinit var clearButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupListeners()
    }

    private fun initViews() {
        inputText = findViewById(R.id.inputText)
        analyzeButton = findViewById(R.id.analyzeButton)
        clearButton = findViewById(R.id.clearButton)
    }

    private fun setupListeners() {
        analyzeButton.setOnClickListener {
            val text = inputText.text.toString().trim()

            if (text.isEmpty()) {
                Toast.makeText(this, "Please enter some text to analyze", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val entities = extractEntities(text)

            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("original_text", text)
            intent.putParcelableArrayListExtra("entities", ArrayList(entities))
            startActivity(intent)
        }

        clearButton.setOnClickListener {
            inputText.text?.clear()
        }
    }

    private fun extractEntities(text: String): List<MedicalEntity> {
        val entities = mutableListOf<MedicalEntity>()
        val lowerText = text.lowercase()

        // Disease patterns
        val diseases = mapOf(
            "diabetes" to "Diabetes",
            "hypertension" to "Hypertension",
            "asthma" to "Asthma",
            "cancer" to "Cancer",
            "pneumonia" to "Pneumonia",
            "tuberculosis" to "Tuberculosis",
            "malaria" to "Malaria",
            "covid" to "COVID-19",
            "coronavirus" to "Coronavirus",
            "influenza" to "Influenza",
            "arthritis" to "Arthritis",
            "alzheimer" to "Alzheimer's Disease",
            "parkinson" to "Parkinson's Disease",
            "stroke" to "Stroke",
            "heart disease" to "Heart Disease",
            "kidney disease" to "Kidney Disease",
            "liver disease" to "Liver Disease",
            "copd" to "COPD",
            "depression" to "Depression",
            "anxiety" to "Anxiety",
            "migraine" to "Migraine",
            "epilepsy" to "Epilepsy",
            "bronchitis" to "Bronchitis",
            "anemia" to "Anemia",
            "leukemia" to "Leukemia",
            "lymphoma" to "Lymphoma",
            "osteoporosis" to "Osteoporosis",
            "gout" to "Gout",
            "psoriasis" to "Psoriasis",
            "eczema" to "Eczema"
        )

        // Drug patterns
        val drugs = mapOf(
            "aspirin" to "Aspirin",
            "ibuprofen" to "Ibuprofen",
            "paracetamol" to "Paracetamol",
            "acetaminophen" to "Acetaminophen",
            "metformin" to "Metformin",
            "insulin" to "Insulin",
            "amoxicillin" to "Amoxicillin",
            "penicillin" to "Penicillin",
            "azithromycin" to "Azithromycin",
            "ciprofloxacin" to "Ciprofloxacin",
            "lisinopril" to "Lisinopril",
            "amlodipine" to "Amlodipine",
            "atorvastatin" to "Atorvastatin",
            "simvastatin" to "Simvastatin",
            "omeprazole" to "Omeprazole",
            "losartan" to "Losartan",
            "levothyroxine" to "Levothyroxine",
            "albuterol" to "Albuterol",
            "prednisone" to "Prednisone",
            "gabapentin" to "Gabapentin",
            "hydrochlorothiazide" to "Hydrochlorothiazide",
            "morphine" to "Morphine",
            "codeine" to "Codeine",
            "warfarin" to "Warfarin",
            "clopidogrel" to "Clopidogrel",
            "diazepam" to "Diazepam",
            "lorazepam" to "Lorazepam",
            "fluoxetine" to "Fluoxetine",
            "sertraline" to "Sertraline",
            "citalopram" to "Citalopram"
        )

        // Symptom patterns
        val symptoms = mapOf(
            "fever" to "Fever",
            "cough" to "Cough",
            "headache" to "Headache",
            "pain" to "Pain",
            "nausea" to "Nausea",
            "vomiting" to "Vomiting",
            "diarrhea" to "Diarrhea",
            "fatigue" to "Fatigue",
            "weakness" to "Weakness",
            "dizziness" to "Dizziness",
            "shortness of breath" to "Shortness of Breath",
            "chest pain" to "Chest Pain",
            "abdominal pain" to "Abdominal Pain",
            "back pain" to "Back Pain",
            "joint pain" to "Joint Pain",
            "muscle pain" to "Muscle Pain",
            "sore throat" to "Sore Throat",
            "runny nose" to "Runny Nose",
            "congestion" to "Congestion",
            "sneezing" to "Sneezing",
            "chills" to "Chills",
            "sweating" to "Sweating",
            "rash" to "Rash",
            "itching" to "Itching",
            "swelling" to "Swelling",
            "bleeding" to "Bleeding",
            "bruising" to "Bruising",
            "numbness" to "Numbness",
            "tingling" to "Tingling",
            "blurred vision" to "Blurred Vision",
            "loss of appetite" to "Loss of Appetite",
            "weight loss" to "Weight Loss",
            "insomnia" to "Insomnia",
            "confusion" to "Confusion",
            "wheezing" to "Wheezing",
            "palpitations" to "Palpitations"
        )

        // Extract diseases
        diseases.forEach { (pattern, name) ->
            if (lowerText.contains(pattern)) {
                entities.add(MedicalEntity(name, "DISEASE"))
            }
        }

        // Extract drugs
        drugs.forEach { (pattern, name) ->
            if (lowerText.contains(pattern)) {
                entities.add(MedicalEntity(name, "DRUG"))
            }
        }

        // Extract symptoms
        symptoms.forEach { (pattern, name) ->
            if (lowerText.contains(pattern)) {
                entities.add(MedicalEntity(name, "SYMPTOM"))
            }
        }

        return entities.distinctBy { it.text }
    }
}