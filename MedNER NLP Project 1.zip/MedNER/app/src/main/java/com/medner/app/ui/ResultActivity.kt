package com.medner.app.ui

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.medner.app.R
import com.medner.app.data.MedicalEntity

class ResultActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var originalText: TextView
    private lateinit var diseasesChipGroup: ChipGroup
    private lateinit var drugsChipGroup: ChipGroup
    private lateinit var symptomsChipGroup: ChipGroup
    private lateinit var diseaseCount: TextView
    private lateinit var drugCount: TextView
    private lateinit var symptomCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        initViews()
        setupToolbar()
        displayResults()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        originalText = findViewById(R.id.originalText)
        diseasesChipGroup = findViewById(R.id.diseasesChipGroup)
        drugsChipGroup = findViewById(R.id.drugsChipGroup)
        symptomsChipGroup = findViewById(R.id.symptomsChipGroup)
        diseaseCount = findViewById(R.id.diseaseCount)
        drugCount = findViewById(R.id.drugCount)
        symptomCount = findViewById(R.id.symptomCount)
    }

    private fun setupToolbar() {
        toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun displayResults() {
        val text = intent.getStringExtra("original_text") ?: ""
        val entities = intent.getParcelableArrayListExtra<MedicalEntity>("entities") ?: arrayListOf()

        originalText.text = text

        val diseases = entities.filter { it.type == "DISEASE" }
        val drugs = entities.filter { it.type == "DRUG" }
        val symptoms = entities.filter { it.type == "SYMPTOM" }

        diseaseCount.text = "(${diseases.size})"
        drugCount.text = "(${drugs.size})"
        symptomCount.text = "(${symptoms.size})"

        // Add disease chips
        diseases.forEach { entity ->
            val chip = createChip(entity.text, R.color.disease_color, R.color.disease_bg)
            diseasesChipGroup.addView(chip)
        }

        if (diseases.isEmpty()) {
            diseasesChipGroup.addView(createEmptyChip())
        }

        // Add drug chips
        drugs.forEach { entity ->
            val chip = createChip(entity.text, R.color.drug_color, R.color.drug_bg)
            drugsChipGroup.addView(chip)
        }

        if (drugs.isEmpty()) {
            drugsChipGroup.addView(createEmptyChip())
        }

        // Add symptom chips
        symptoms.forEach { entity ->
            val chip = createChip(entity.text, R.color.symptom_color, R.color.symptom_bg)
            symptomsChipGroup.addView(chip)
        }

        if (symptoms.isEmpty()) {
            symptomsChipGroup.addView(createEmptyChip())
        }
    }

    private fun createChip(text: String, textColorRes: Int, bgColorRes: Int): Chip {
        return Chip(this).apply {
            this.text = text
            setTextColor(getColor(textColorRes))
            setChipBackgroundColorResource(bgColorRes)
            isClickable = false
            isCheckable = false
            textSize = 14f
        }
    }

    private fun createEmptyChip(): Chip {
        return Chip(this).apply {
            text = "None found"
            setTextColor(getColor(R.color.text_secondary))
            setChipBackgroundColorResource(R.color.background)
            isClickable = false
            isCheckable = false
            textSize = 14f
        }
    }
}