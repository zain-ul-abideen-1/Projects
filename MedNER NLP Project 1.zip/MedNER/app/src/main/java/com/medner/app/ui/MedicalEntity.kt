package com.medner.app.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MedicalEntity(
    val text: String,
    val type: String  // DISEASE, DRUG, or SYMPTOM
) : Parcelable