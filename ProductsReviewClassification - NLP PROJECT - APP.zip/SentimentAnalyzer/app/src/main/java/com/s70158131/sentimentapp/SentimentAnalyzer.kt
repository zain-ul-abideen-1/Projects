package com.s70158131.sentimentapp

class SentimentAnalyzer {

    private val positiveWords = listOf(
        "good", "great", "excellent", "amazing", "wonderful", "fantastic", "awesome",
        "love", "best", "perfect", "beautiful", "brilliant", "outstanding", "superb",
        "happy", "pleased", "satisfied", "delighted", "impressed", "recommend", "quality",
        "helpful", "useful", "effective", "reliable", "professional", "friendly"
    )

    private val negativeWords = listOf(
        "bad", "terrible", "awful", "horrible", "worst", "hate", "poor", "disappointing",
        "useless", "waste", "pathetic", "garbage", "disgusting", "annoying", "frustrating",
        "broken", "defective", "fail", "failed", "problem", "issue", "complaint", "refund",
        "never", "avoid", "worthless", "regret"
    )

    private val helpfulIndicators = listOf(
        "detail", "specific", "because", "reason", "explain", "experience", "tried",
        "used", "quality", "feature", "pros", "cons", "recommend", "compare", "versus",
        "would", "suggest", "advice", "tip", "warning", "note", "important", "worth"
    )

    fun analyzeSentiment(text: String): Pair<String, Int> {
        val lowerText = text.lowercase()
        val words = lowerText.split(Regex("\\W+"))

        var positiveCount = 0
        var negativeCount = 0

        for (word in words) {
            if (positiveWords.contains(word)) {
                positiveCount++
            }
            if (negativeWords.contains(word)) {
                negativeCount++
            }
        }

        // Check for negation words before positive words
        val negationWords = listOf("not", "no", "never", "neither", "nobody", "nothing")
        for (i in 0 until words.size - 1) {
            if (negationWords.contains(words[i]) && positiveWords.contains(words[i + 1])) {
                positiveCount--
                negativeCount++
            }
        }

        val totalSentimentWords = positiveCount + negativeCount

        return when {
            totalSentimentWords == 0 -> {
                // Neutral if no sentiment words found
                Pair("Neutral", 50)
            }
            positiveCount > negativeCount -> {
                val score = ((positiveCount.toFloat() / totalSentimentWords) * 100).toInt()
                Pair("Positive", score.coerceIn(60, 100))
            }
            negativeCount > positiveCount -> {
                val score = ((negativeCount.toFloat() / totalSentimentWords) * 100).toInt()
                Pair("Negative", score.coerceIn(60, 100))
            }
            else -> {
                Pair("Neutral", 50)
            }
        }
    }

    fun analyzeHelpfulness(text: String): Pair<String, Int> {
        val lowerText = text.lowercase()
        val words = lowerText.split(Regex("\\W+"))
        val wordCount = words.size

        // Calculate helpfulness based on multiple factors
        var helpfulnessScore = 0

        // Factor 1: Length (longer reviews tend to be more helpful)
        when {
            wordCount > 15 -> helpfulnessScore += 50
            wordCount > 8 -> helpfulnessScore += 20
            wordCount > 4 -> helpfulnessScore += 10
        }

        // Factor 2: Contains helpful indicators
        var indicatorCount = 0
        for (word in words) {
            if (helpfulIndicators.contains(word)) {
                indicatorCount++
            }
        }
        helpfulnessScore += (indicatorCount * 5).coerceAtMost(40)

        // Factor 3: Has specific details (sentences with numbers, comparisons)
        if (lowerText.contains(Regex("\\d+"))) {
            helpfulnessScore += 15
        }

        // Factor 4: Balanced content (has both positive and negative aspects)
        val hasPositive = positiveWords.any { lowerText.contains(it) }
        val hasNegative = negativeWords.any { lowerText.contains(it) }
        if (hasPositive && hasNegative) {
            helpfulnessScore += 15
        }

        val finalScore = helpfulnessScore.coerceIn(0, 100)

        return if (finalScore >= 50) {
            Pair("Helpful", finalScore)
        } else {
            Pair("Not Helpful", finalScore)
        }
    }
}