package com.s70158131.sentimentapp

import android.graphics.Color
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class AnalysisActivity : AppCompatActivity() {

    private lateinit var backButton: ImageButton
    private lateinit var analyzedText: TextView
    private lateinit var sentimentResult: TextView
    private lateinit var sentimentScore: TextView
    private lateinit var helpfulnessResult: TextView
    private lateinit var helpfulnessScore: TextView
    private lateinit var analyzeAnotherButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analysis)

        backButton = findViewById(R.id.backButton)
        analyzedText = findViewById(R.id.analyzedText)
        sentimentResult = findViewById(R.id.sentimentResult)
        sentimentScore = findViewById(R.id.sentimentScore)
        helpfulnessResult = findViewById(R.id.helpfulnessResult)
        helpfulnessScore = findViewById(R.id.helpfulnessScore)
        analyzeAnotherButton = findViewById(R.id.analyzeAnotherButton)

        val inputText = intent.getStringExtra("INPUT_TEXT") ?: ""
        analyzedText.text = inputText

        val analyzer = SentimentAnalyzer()
        val sentiment = analyzer.analyzeSentiment(inputText)
        val helpfulness = analyzer.analyzeHelpfulness(inputText)

        displayResults(sentiment, helpfulness)

        backButton.setOnClickListener {
            finish()
        }

        analyzeAnotherButton.setOnClickListener {
            finish()
        }
    }

    private fun displayResults(sentiment: Pair<String, Int>, helpfulness: Pair<String, Int>) {
        // Display sentiment
        sentimentResult.text = sentiment.first
        sentimentScore.text = "${sentiment.second}%"

        when (sentiment.first) {
            "Positive" -> {
                sentimentResult.setTextColor(getColor(R.color.positive))
                sentimentScore.setTextColor(getColor(R.color.positive))
            }
            "Neutral" -> {
                sentimentResult.setTextColor(getColor(R.color.neutral))
                sentimentScore.setTextColor(getColor(R.color.neutral))
            }
            "Negative" -> {
                sentimentResult.setTextColor(getColor(R.color.negative))
                sentimentScore.setTextColor(getColor(R.color.negative))
            }
        }

        // Display helpfulness
        helpfulnessResult.text = helpfulness.first
        helpfulnessScore.text = "${helpfulness.second}%"

        when (helpfulness.first) {
            "Helpful" -> {
                helpfulnessResult.setTextColor(getColor(R.color.helpful))
                helpfulnessScore.setTextColor(getColor(R.color.helpful))
            }
            "Not Helpful" -> {
                helpfulnessResult.setTextColor(getColor(R.color.not_helpful))
                helpfulnessScore.setTextColor(getColor(R.color.not_helpful))
            }
        }
    }
}
