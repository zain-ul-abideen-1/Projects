
package ciphertool;

public class VigenereCipher {
    public static String decrypt(String cipherText, String key) {
        StringBuilder result = new StringBuilder();
        key = key.toUpperCase();
        cipherText = cipherText.toUpperCase();

        for (int i = 0, j = 0; i < cipherText.length(); i++) {
            char c = cipherText.charAt(i);
            if (c < 'A' || c > 'Z') {
                result.append(c);
                continue;
            }
            result.append((char)((c - key.charAt(j) + 26) % 26 + 'A'));
            j = ++j % key.length();
        }
        return result.toString();
    }

    public static String encrypt(String plainText, String key) {
        StringBuilder result = new StringBuilder();
        key = key.toUpperCase();
        plainText = plainText.toUpperCase();

        for (int i = 0, j = 0; i < plainText.length(); i++) {
            char c = plainText.charAt(i);
            if (c < 'A' || c > 'Z') {
                result.append(c);
                continue;
            }
            result.append((char)((c + key.charAt(j) - 2 * 'A') % 26 + 'A'));
            j = ++j % key.length();
        }
        return result.toString();
    }
}
