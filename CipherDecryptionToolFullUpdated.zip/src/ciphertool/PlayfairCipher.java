
package ciphertool;

public class PlayfairCipher {
    public static String decrypt(String cipherText, String key) {
        return "[Playfair decrypted] " + cipherText;
    }

    public static String encrypt(String plainText, String key) {
        return "[Playfair encrypted] " + plainText;
    }
}
