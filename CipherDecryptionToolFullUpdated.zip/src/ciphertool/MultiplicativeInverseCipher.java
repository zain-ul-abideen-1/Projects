
package ciphertool;

public class MultiplicativeInverseCipher {
    public static String decrypt(String cipherText, int key) {
        int inverse = 0;
        for (int i = 1; i < 26; i++) {
            if ((key * i) % 26 == 1) {
                inverse = i;
                break;
            }
        }

        StringBuilder decrypted = new StringBuilder();
        for (char c : cipherText.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                int value = (c - base);
                int decryptedValue = (inverse * value) % 26;
                decrypted.append((char)(decryptedValue + base));
            } else {
                decrypted.append(c);
            }
        }
        return decrypted.toString();
    }

    public static String encrypt(String plainText, int key) {
        StringBuilder encrypted = new StringBuilder();
        for (char c : plainText.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                int value = (c - base);
                int encryptedValue = (key * value) % 26;
                encrypted.append((char)(encryptedValue + base));
            } else {
                encrypted.append(c);
            }
        }
        return encrypted.toString();
    }
}
