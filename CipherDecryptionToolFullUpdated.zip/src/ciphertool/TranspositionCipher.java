
package ciphertool;

public class TranspositionCipher {
    public static String decrypt(String cipherText) {
        int numRows = 2;
        int numCols = (int) Math.ceil((double) cipherText.length() / numRows);
        char[][] grid = new char[numRows][numCols];

        int index = 0;
        for (int col = 0; col < numCols; col++) {
            for (int row = 0; row < numRows; row++) {
                if (index < cipherText.length()) {
                    grid[row][col] = cipherText.charAt(index++);
                } else {
                    grid[row][col] = ' ';
                }
            }
        }

        StringBuilder plainText = new StringBuilder();
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                plainText.append(grid[row][col]);
            }
        }

        return plainText.toString().trim();
    }

    public static String encrypt(String plainText) {
        int numRows = 2;
        int numCols = (int) Math.ceil((double) plainText.length() / numRows);
        char[][] grid = new char[numRows][numCols];

        int index = 0;
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                if (index < plainText.length()) {
                    grid[row][col] = plainText.charAt(index++);
                } else {
                    grid[row][col] = ' ';
                }
            }
        }

        StringBuilder cipherText = new StringBuilder();
        for (int col = 0; col < numCols; col++) {
            for (int row = 0; row < numRows; row++) {
                cipherText.append(grid[row][col]);
            }
        }

        return cipherText.toString().trim();
    }
}
