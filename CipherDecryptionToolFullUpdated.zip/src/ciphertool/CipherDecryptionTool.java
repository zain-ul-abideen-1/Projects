
package ciphertool;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CipherDecryptionTool {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CipherDecryptionTool().createAndShowGUI());
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame("Cipher Tool with Defense Mode");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Encrypt/Decrypt Panel
        JPanel cipherPanel = new JPanel(new BorderLayout());

        JTextArea inputArea = new JTextArea(10, 60);
        JTextArea outputArea = new JTextArea(10, 60);
        outputArea.setEditable(false);

        String[] ciphers = {
            "Caesar Cipher",
            "Transposition Cipher",
            "Double Transposition Cipher",
            "Triple Transposition Cipher",
            "Playfair Cipher",
            "Vigenere Cipher",
            "Multiplicative Inverse Cipher"
        };
        JComboBox<String> cipherSelector = new JComboBox<>(ciphers);
        JRadioButton encryptButton = new JRadioButton("Encrypt");
        JRadioButton decryptButton = new JRadioButton("Decrypt");
        decryptButton.setSelected(true);
        ButtonGroup group = new ButtonGroup();
        group.add(encryptButton);
        group.add(decryptButton);

        JButton processButton = new JButton("Run");

        processButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedCipher = (String) cipherSelector.getSelectedItem();
                String inputText = inputArea.getText().trim();
                String result = "";

                boolean isEncrypt = encryptButton.isSelected();

                switch (selectedCipher) {
                    case "Caesar Cipher":
                        result = isEncrypt ? CaesarCipher.encrypt(inputText, 3) : CaesarCipher.decrypt(inputText, 3); break;
                    case "Transposition Cipher":
                        result = isEncrypt ? TranspositionCipher.encrypt(inputText) : TranspositionCipher.decrypt(inputText); break;
                    case "Double Transposition Cipher":
                        if (isEncrypt) {
                            result = TranspositionCipher.encrypt(TranspositionCipher.encrypt(inputText));
                        } else {
                            result = TranspositionCipher.decrypt(TranspositionCipher.decrypt(inputText));
                        }
                        break;
                    case "Triple Transposition Cipher":
                        if (isEncrypt) {
                            result = TranspositionCipher.encrypt(TranspositionCipher.encrypt(TranspositionCipher.encrypt(inputText)));
                        } else {
                            result = TranspositionCipher.decrypt(TranspositionCipher.decrypt(TranspositionCipher.decrypt(inputText)));
                        }
                        break;
                    case "Playfair Cipher":
                        result = isEncrypt ? PlayfairCipher.encrypt(inputText, "KEYWORD") : PlayfairCipher.decrypt(inputText, "KEYWORD"); break;
                    case "Vigenere Cipher":
                        result = isEncrypt ? VigenereCipher.encrypt(inputText, "KEY") : VigenereCipher.decrypt(inputText, "KEY"); break;
                    case "Multiplicative Inverse Cipher":
                        result = isEncrypt ? MultiplicativeInverseCipher.encrypt(inputText, 5) : MultiplicativeInverseCipher.decrypt(inputText, 5); break;
                }

                outputArea.setText(result);
            }
        });

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Select Cipher:"));
        topPanel.add(cipherSelector);
        topPanel.add(encryptButton);
        topPanel.add(decryptButton);
        topPanel.add(processButton);

        JPanel centerPanel = new JPanel(new GridLayout(2, 1));
        centerPanel.add(new JScrollPane(inputArea));
        centerPanel.add(new JScrollPane(outputArea));

        cipherPanel.add(topPanel, BorderLayout.NORTH);
        cipherPanel.add(centerPanel, BorderLayout.CENTER);

        // Defense Panel
        JPanel defensePanel = new JPanel(new BorderLayout());
        JTextArea defenseOutput = new JTextArea(20, 60);
        defenseOutput.setEditable(false);
        JButton generateDefenseBtn = new JButton("Generate Defense Message");

        generateDefenseBtn.addActionListener(e -> {
            StringBuilder sb = new StringBuilder("⚠️ CYBER DEFENSE MESSAGE INITIATED ⚠️\n\n");
            for (int i = 0; i < 1000; i++) {
                sb.append("X0X1X0X1").append((char)(65 + (i % 26))).append("🔥💣🚫");
            }
            defenseOutput.setText(sb.toString());
        });

        JPanel btnPanel = new JPanel();
        btnPanel.add(generateDefenseBtn);
        defensePanel.add(btnPanel, BorderLayout.NORTH);
        defensePanel.add(new JScrollPane(defenseOutput), BorderLayout.CENTER);

        tabbedPane.add("Encrypt / Decrypt", cipherPanel);
        tabbedPane.add("Defense Mode", defensePanel);

        frame.add(tabbedPane);
        frame.setVisible(true);
    }
}
