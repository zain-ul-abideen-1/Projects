// RestaurantManagementSystem.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;import java.sql.SQLException;

public class RestaurantManagementSystem {
    private static final String DB_URL = "jdbc:sqlite:Resturant.db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(RestaurantManagementSystem::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 1, 10, 10));

        JButton addDishButton = new JButton("Add New Dish");
        JButton viewMenuButton = new JButton("View Menu");
        JButton takeOrderButton = new JButton("Take Order");
        JButton viewOrdersButton = new JButton("View Orders");
        JButton updateDishButton = new JButton("Update Dish");
        JButton deleteDishButton = new JButton("Delete Dish");
        JButton exitButton = new JButton("Exit");

        panel.add(addDishButton);
        panel.add(viewMenuButton);
        panel.add(takeOrderButton);
        panel.add(viewOrdersButton);
        panel.add(updateDishButton);
        panel.add(deleteDishButton);
        panel.add(exitButton);

        frame.add(panel);
        frame.setVisible(true);

        try (Connection connection = DriverManager.getConnection(DB_URL)) {
            addDishButton.addActionListener( e -> addNewDishGUI(connection));
            viewMenuButton.addActionListener(e -> viewMenuGUI(connection));
            takeOrderButton.addActionListener(e -> takeOrderGUI(connection));
            viewOrdersButton.addActionListener(e -> viewOrdersGUI(connection));
            updateDishButton.addActionListener(e -> updateDishGUI(connection));
            deleteDishButton.addActionListener(e -> deleteDishGUI(connection));
            exitButton.addActionListener(e -> System.exit(0));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void addNewDishGUI(Connection connection) {
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();

        Object[] message = {
                "Dish Name:", nameField,
                "Dish Price:", priceField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Add New Dish", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());

                String sql = "INSERT INTO menu (name, price) VALUES (?, ?)";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, name);
                    pstmt.setDouble(2, price);
                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Dish added successfully.");
                }
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewMenuGUI(Connection connection) {
        String sql = "SELECT * FROM menu";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            StringBuilder menu = new StringBuilder("Menu:\n");
            while (rs.next()) {
                menu.append(String.format("ID: %d | Name: %s | Price: %.2f\n", rs.getInt("id"), rs.getString("name"), rs.getDouble("price")));
            }
            JTextArea textArea = new JTextArea(menu.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            JOptionPane.showMessageDialog(null, scrollPane, "Menu", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void takeOrderGUI(Connection connection) {
        JTextField customerField = new JTextField();
        JTextField dishIdField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] message = {
                "Customer Name:", customerField,
                "Dish ID:", dishIdField,
                "Quantity:", quantityField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Take Order", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String customerName = customerField.getText();
                int dishId = Integer.parseInt(dishIdField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                String date = java.time.LocalDate.now().toString();

                String dishQuery = "SELECT price FROM menu WHERE id = ?";
                double price = 0;
                try (PreparedStatement pstmt = connection.prepareStatement(dishQuery)) {
                    pstmt.setInt(1, dishId);
                    ResultSet rs = pstmt.executeQuery();
                    if (rs.next()) {
                        price = rs.getDouble("price");
                    }
                }

                double totalBill = price * quantity;

                String sql = "INSERT INTO orders (customer_name, dish_id, quantity, order_date, total_bill) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, customerName);
                    pstmt.setInt(2, dishId);
                    pstmt.setInt(3, quantity);
                    pstmt.setString(4, date);
                    pstmt.setDouble(5, totalBill);
                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, String.format("Order placed successfully. Total Bill: %.2f", totalBill));
                }
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void viewOrdersGUI(Connection connection) {
        String sql = "SELECT o.id, o.customer_name, m.name AS dish_name, o.quantity, o.order_date, o.total_bill FROM orders o JOIN menu m ON o.dish_id = m.id";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            StringBuilder orders = new StringBuilder("Orders:\n");
            while (rs.next()) {
                orders.append(String.format("Order ID: %d | Customer: %s | Dish: %s | Quantity: %d | Date: %s | Total Bill: %.2f\n",
                        rs.getInt("id"), rs.getString("customer_name"), rs.getString("dish_name"), rs.getInt("quantity"), rs.getString("order_date"), rs.getDouble("total_bill")));
            }
            JTextArea textArea = new JTextArea(orders.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            JOptionPane.showMessageDialog(null, scrollPane, "Orders", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void updateDishGUI(Connection connection) {
        JTextField dishIdField = new JTextField();
        JTextField newNameField = new JTextField();
        JTextField newPriceField = new JTextField();

        Object[] message = {
                "Dish ID:", dishIdField,
                "New Name:", newNameField,
                "New Price:", newPriceField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Update Dish", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int dishId = Integer.parseInt(dishIdField.getText());
                String newName = newNameField.getText();
                double newPrice = Double.parseDouble(newPriceField.getText());

                String sql = "UPDATE menu SET name = ?, price = ? WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setString(1, newName);
                    pstmt.setDouble(2, newPrice);
                    pstmt.setInt(3, dishId);
                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Dish updated successfully.");
                }
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void deleteDishGUI(Connection connection) {
        JTextField dishIdField = new JTextField();

        Object[] message = {
                "Dish ID:", dishIdField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Delete Dish", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int dishId = Integer.parseInt(dishIdField.getText());

                String sql = "DELETE FROM menu WHERE id = ?";
                try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                    pstmt.setInt(1, dishId);
                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Dish deleted successfully.");
                }
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
